function [a,h,v,d] = dwt2(x,arg2,arg3)
%DWT2 Single-level discrete 2-D wavelet transform.
%       DWT2 performs a single-level 2-D wavelet decomposition
%       with respect to either a particular wavelet ('wname',
%       see WFILTERS) or particular wavelet filters
%       (Lo_D and Hi_D) you specify.
%
%       [CA,CH,CV,CD] = DWT2(X,'wname') computes the approximation
%       coefficients matrix CA and details coefficients matrices 
%       CH, CV, CD, obtained by wavelet decomposition of the 
%       input matrix X.
%       'wname' is a string containing the wavelet name.
%
%       [CA,CH,CV,CD] = DWT2(X,Lo_D,Hi_D) computes the 2-Dwavelet
%       decomposition as above given these filters as input:
%       Lo_D is the decomposition low-pass filter and
%       Hi_D is the decomposition high-pass filter.
%       Lo_D and Hi_D must be the same length.
%
%       If sx = size(X) and lf is the length of filters then
%       size(CA) = size(CH) = size(CV) = size(CD) = 
%                                        FLOOR((sx+lf-1)/2).
%
%       For the different DWT extension modes, see DWTMODE. 
%
%       See also DWTMODE, DWTPER2, IDWT2, WAVEDEC2, WAVEINFO.

%       M. Misiti, Y. Misiti, G. Oppenheim, J.M. Poggi 12-Mar-96.
%       Copyright (c) 1995-96 by The Mathworks, Inc.
%       $Revision: 1.1 $  $Date: 1996/03/05 21:10:06 $

%       Uses DYADDOWN, WKEEP, WFILTERS.

global DWT_Ext_Mode

% Check arguments.
if errargn('dwt2',nargin,[2 3],nargout,[0,1,4]), error('*'), end
if nargin==2
        [LoF_D,HiF_D] = wfilters(arg2,'d');
else
        LoF_D = arg2;   HiF_D = arg3;
end

if      isempty(DWT_Ext_Mode) | DWT_Ext_Mode=='zpd' % zpd is the default

        % Decomposition.
        y = dyaddown(conv2(x,LoF_D),'c');
        a = dyaddown(conv2(y,LoF_D'),'r');
        h = dyaddown(conv2(y,HiF_D'),'r');

        y = dyaddown(conv2(x,HiF_D),'c');
        v = dyaddown(conv2(y,LoF_D'),'r');
        d = dyaddown(conv2(y,HiF_D'),'r');

elseif  DWT_Ext_Mode=='sym'

        % Symmetrization.
        sx = size(x);        rx = sx(1);        cx = sx(2);
        lf = length(LoF_D);
        x  = [x(:,lf:-1:1) x x(:,cx:-1:cx-lf+1)];
        x  = [x(lf:-1:1,:);x;x(rx:-1:rx-lf+1,:)];

        % Decomposition.
        sa = floor((sx+lf-1)/2);
        y  = dyaddown(conv2(x,LoF_D),'c');
        a  = wkeep(dyaddown(conv2(y,LoF_D'),'r'),sa);
        h  = wkeep(dyaddown(conv2(y,HiF_D'),'r'),sa);

        y  = dyaddown(conv2(x,HiF_D),'c');
        v  = wkeep(dyaddown(conv2(y,LoF_D'),'r'),sa);
        d  = wkeep(dyaddown(conv2(y,HiF_D'),'r'),sa);

elseif  DWT_Ext_Mode=='spd'

        % Smooth padding.
        sx = size(x);        rx = sx(1);        cx = sx(2);
        lf = length(LoF_D);
        x  = [zeros(rx,lf) x zeros(rx,lf)];
        for k=lf:-1:1
                x(:,k) = 2*x(:,k+1)-x(:,k+2);
        end
        for k=lf+cx+1:cx+2*lf
                x(:,k) = 2*x(:,k-1)-x(:,k-2);
        end
        x  = [zeros(lf,cx+2*lf);x;zeros(lf,cx+2*lf)];
        for k=lf:-1:1
                x(k,:) = 2*x(k+1,:)-x(k+2,:);
        end
        for k=lf+rx+1:rx+2*lf
                x(k,:) = 2*x(k-1,:)-x(k-2,:);
        end

        % Decomposition.
        sa = floor((sx+lf-1)/2);
        y  = dyaddown(conv2(x,LoF_D),'c');
        a  = wkeep(dyaddown(conv2(y,LoF_D'),'r'),sa);
        h  = wkeep(dyaddown(conv2(y,HiF_D'),'r'),sa);

        y  = dyaddown(conv2(x,HiF_D),'c');
        v  = wkeep(dyaddown(conv2(y,LoF_D'),'r'),sa);
        d  = wkeep(dyaddown(conv2(y,HiF_D'),'r'),sa);

else
        errargt('dwt2','Invalid Extension Mode for DWT!','msg');
        error('*')
end
