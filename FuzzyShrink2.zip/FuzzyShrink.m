
%**************************************************************************
% FuzzyShrink
%
%  The main program of the fuzzy shrinkage method proposed for published in: 
%
%  Stefan Schulte, Bruno Huysmans, Aleksandra Pizurica, Etienne E. Kerre 
%  and  Wilfried Philips: A New Fuzzy-based Wavelet Shrinkage Image Denoising Technique
%  submitted to the conference "Advanced Concepts for Intelligent Vision Systems" 
%  Sept 18-21, 2006,  Antwerp, Belgium 
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 07/04/06
%**************************************************************************

% For noisy input greyscale image noise and original noise free image 'orig'
noise = imread('E:/ruis_bar.bmp');
orig = imread('E:/images/barbara.bmp');

X = double(noise(:,:,1));
O = double(orig(:,:,1));
[M,N]=size(O);

% Noise estimation proposed by Donoho
%   [DO94] Donoho, D.L.,  Johnstone, I.M.: Ideal spatial adaptation by wavelet shrinkage.
%          Biometrika 81 (1994) 425-455
[clp,chor,cver,cdiag]=dwt2(X,'db1');
sigma=Thr_univ(cdiag);

% neighbourhood size 
WindowSize = 4;

% wavelet transformation
wtype='db2'
h = daubcqf(4,'min');  

%wtype='db4'
%h = daubcqf(8,'min');

%wtype='db8'
%h = daubcqf(16,'min');
    
%wtype='sym2'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym2');
%h=LO_R;
    
%wtype='sym4'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym4');
%h=LO_R;
    
%wtype='sym8'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym8');
%h=LO_R;
 
% We use four scales
L=4;
[yl,yh,L] = mrdwt(double(X),h,L);
 
LH1 = yh(:,1:N); 
HL1 = yh(:,N+1:2*N); 
HH1 = yh(:,2*N+1:3*N);
 
LH2 = yh(:,3*N+1:4*N); 
HL2 = yh(:,4*N+1:5*N); 
HH2 = yh(:,5*N+1:6*N);
 
LH3 = yh(:,6*N+1:7*N); 
HL3 = yh(:,7*N+1:8*N); 
HH3 = yh(:,8*N+1:9*N);
 
LH4 = yh(:,9*N+1:10*N); 
HL4 = yh(:,10*N+1:11*N); 
HH4 = yh(:,11*N+1:12*N);
 


% Scale 4
HL4p = noise_reduction(HL4,WindowSize,sigma);
LH4p = noise_reduction(LH4,WindowSize,sigma);
HH4p = noise_reduction(HH4,WindowSize,sigma);

% Scale 3
HL3p = noise_reduction(HL3,WindowSize,sigma);
LH3p = noise_reduction(LH3,WindowSize,sigma);
HH3p = noise_reduction(HH3,WindowSize,sigma);

% Scale 2
HL2p = noise_reduction(HL2,WindowSize,sigma);
LH2p = noise_reduction(LH2,WindowSize,sigma);
HH2p = noise_reduction(HH2,WindowSize,sigma);

% Scale 1
HL1p = noise_reduction(HL1,WindowSize,sigma);
LH1p = noise_reduction(LH1,WindowSize,sigma);
HH1p = noise_reduction(HH1,WindowSize,sigma);


% Reconstruction
yhp=yh;
[M,N] = size(LH1p);
yhp(:,1:N)=LH1p; 
yhp(:,N+1:2*N)=HL1p; 
yhp(:,2*N+1:3*N)=HH1p;
 
yhp(:,3*N+1:4*N)=LH2p; 
yhp(:,4*N+1:5*N)=HL2p; 
yhp(:,5*N+1:6*N)=HH2p;
 
yhp(:,6*N+1:7*N)=LH3p; 
yhp(:,7*N+1:8*N)=HL3p; 
yhp(:,8*N+1:9*N)=HH3p;
 
yhp(:,9*N+1:10*N)=LH4p; 
yhp(:,10*N+1:11*N)=HL4p; 
yhp(:,11*N+1:12*N)=HH4p;
 
[R,L] = mirdwt(yl,yhp,h,L);

Rs(:,:,1) = R;
Rs(:,:,2) = R;
Rs(:,:,3) = R;