%**************************************************************************
% noise_reduction
%
%  The fuzzy shrinkage denoising method:
%      Input arguments
%              D: noisy input wavelet band
%              W: neighbourhood size 
%          sigma: the standard deviation of the noise
%
%      Output arguments
%           D_cl: the output (denoised wavelet band)
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 07/04/06
%**************************************************************************

function D_cl = noise_reduction(D,W,sigma);

% 'shrink' is implemented in C (cf. shrink.c)
clear SHRINK;
SHRINK = shrink(D,W,sigma);

D_cl = D.*SHRINK;






