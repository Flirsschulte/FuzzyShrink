function y=Thr_univ(X)

med=median(median(X));
y=median(median(abs(X-med)))/0.6745;