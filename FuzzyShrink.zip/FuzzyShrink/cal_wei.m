
function D_cl = noise_reduction(D,si);

D_cl = D;
[M,N] = size(D);
for i = si+1:M
    for j= si+1:N
        som = 0;
        for k = -si:0
            for l = -si:0
                som = som + D(i+k,j+l);
            end
        end
        D_cl(i,j) = som/((si+1)^2);
    end
end






