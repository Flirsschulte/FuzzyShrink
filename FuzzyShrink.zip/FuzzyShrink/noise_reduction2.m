%**************************************************************************
% noise_reduction
%
%  The fuzzy shrinkage denoising method:
%      Input arguments
%              D: noisy input wavelet band
%              W: neighbourhood size 
%          sigma: the standard deviation of the noise
%
%      Output arguments
%           D_cl: the output (denoised wavelet band)
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 07/04/06
%**************************************************************************

function [D_cl,ti] = noise_reduction2(D,W,sigma);

% 'shrink' is implemented in C (cf. shrink.c)
clear SHRINK;
t=clock;
SHRINK = shrink(D,W,sigma);
ti=etime(clock,t);  


D_cl = D.*SHRINK;






