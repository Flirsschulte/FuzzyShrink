function Out = FuzzyShrink2(A,W);

%**************************************************************************
% Fuzzy Wavelet Shrinkage Method 
%
%  The main program of the fuzzy shrinkage method proposed in: 
%
%  Stefan Schulte, Bruno Huysmans, Aleksandra Pizurica, Etienne E. Kerre 
%  and  Wilfried Philips: A New Fuzzy-based Wavelet Shrinkage Image Denoising Technique
%  Lecture Notes in Computer Science conference 
%  "Advanced Concepts for Intelligent Vision Systems" 
%  Sept 18-21, 2006,  Antwerp, Belgium 
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 07/04/06
%
% Inputs:  A = the noisy input image
%          W = the window-size
%          We used the simple Daubechies db2 wavelet transform 
% Outputs:  Out = the filtered image 
%**************************************************************************

[M,N,D]=size(A);
X = double(A(:,:,1));

% Noise estimation proposed by Donoho
% Donoho, D.L.,  Johnstone, I.M.: Ideal spatial adaptation by wavelet shrinkage.
% Biometrika 81 (1994) 425-455
[clp,chor,cver,cdiag]=dwt2(X,'db1');
sigma=Thr_univ(cdiag);
%sigma=10;

% neighbourhood size 
WindowSize = W;

% wavelet transformation 'This can be changed here'
wtype='db2';
h = daubcqf(4,'min');  

%wtype='db4'
%h = daubcqf(8,'min');

%wtype='db8'
%h = daubcqf(16,'min');
    
%wtype='sym2'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym2');
%h=LO_R;
    
%wtype='sym4'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym4');
%h=LO_R;
    
%wtype='sym8'
%[LO_D,HI_D,LO_R,HI_R] = wfilters('sym8');
%h=LO_R;
 
% We use four scales
L=4;
[yl,yh,L] = mrdwt(double(X),h,L);
 
LH1 = yh(:,1:N); 
HL1 = yh(:,N+1:2*N); 
HH1 = yh(:,2*N+1:3*N);
 
LH2 = yh(:,3*N+1:4*N); 
HL2 = yh(:,4*N+1:5*N); 
HH2 = yh(:,5*N+1:6*N);
 
LH3 = yh(:,6*N+1:7*N); 
HL3 = yh(:,7*N+1:8*N); 
HH3 = yh(:,8*N+1:9*N);
 
LH4 = yh(:,9*N+1:10*N); 
HL4 = yh(:,10*N+1:11*N); 
HH4 = yh(:,11*N+1:12*N);
 
% Scale 4
[HL4p,ti1] = noise_reduction2(HL4,WindowSize,sigma);
[LH4p,ti2] = noise_reduction2(LH4,WindowSize,sigma);
[HH4p,ti3] = noise_reduction2(HH4,WindowSize,sigma);

% Scale 3
[HL3p,ti4] = noise_reduction2(HL3,WindowSize,sigma);
[LH3p,ti5] = noise_reduction2(LH3,WindowSize,sigma);
[HH3p,ti6] = noise_reduction2(HH3,WindowSize,sigma);

% Scale 2
[HL2p,ti7] = noise_reduction2(HL2,WindowSize,sigma);
[LH2p,ti8] = noise_reduction2(LH2,WindowSize,sigma);
[HH2p,ti9] = noise_reduction2(HH2,WindowSize,sigma);

% Scale 1
[HL1p,ti10] = noise_reduction2(HL1,WindowSize,sigma);
[LH1p,ti11] = noise_reduction2(LH1,WindowSize,sigma);
[HH1p,ti12] = noise_reduction2(HH1,WindowSize,sigma);

ti = (ti1 + ti2 + ti3 + ti4 + ti5 + ti6 + ti7 + ti8 + ti9 + ti10 + ti11 + ti12)/9.0;

% Reconstruction
yhp=yh;
[M,N] = size(LH1p);
yhp(:,1:N)=LH1p; 
yhp(:,N+1:2*N)=HL1p; 
yhp(:,2*N+1:3*N)=HH1p;
 
yhp(:,3*N+1:4*N)=LH2p; 
yhp(:,4*N+1:5*N)=HL2p; 
yhp(:,5*N+1:6*N)=HH2p;
 
yhp(:,6*N+1:7*N)=LH3p; 
yhp(:,7*N+1:8*N)=HL3p; 
yhp(:,8*N+1:9*N)=HH3p;
 
yhp(:,9*N+1:10*N)=LH4p; 
yhp(:,10*N+1:11*N)=HL4p; 
yhp(:,11*N+1:12*N)=HH4p;
 
[R,L] = mirdwt(yl,yhp,h,L);

Out(:,:) = R;
