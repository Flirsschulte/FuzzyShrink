function Out = FuzzyShrink(A,W);

%**************************************************************************
% Fuzzy Wavelet Shrinkage Method 
%
%  The main program of the fuzzy shrinkage method proposed in: 
%
%  Stefan Schulte, Bruno Huysmans, Aleksandra Pizurica, Etienne E. Kerre 
%  and  Wilfried Philips: A New Fuzzy-based Wavelet Shrinkage Image Denoising Technique
%  Lecture Notes in Computer Science conference 
%  "Advanced Concepts for Intelligent Vision Systems" 
%  Sept 18-21, 2006,  Antwerp, Belgium 
%
% Stefan Schulte (stefan.schulte@Ugent.be):
% Last modified: 07/04/06
%
% Inputs:  A = the noisy input image
%          W = the window-size
%          We used the simple Daubechies db2 wavelet transform 
% Outputs:  Out = the filtered image 
%**************************************************************************

[M,N,D]=size(A);
Out(M,N,D) = 0;
A = double(A);

if (D == 3) & ((sum(sum(A(:,:,2) ~= A(:,:,3))) > 900) | (sum(sum(A(:,:,1) ~= A(:,:,3))) > 900)) 
    Out1 = FuzzyShrink(A(:,:,1),W);
    Out2 = FuzzyShrink(A(:,:,2),W);
    Out3 = FuzzyShrink(A(:,:,3),W);
    
    Out(:,:,1) = Out1(:,:,1);
    Out(:,:,2) = Out2(:,:,1);
    Out(:,:,3) = Out3(:,:,1);
else
    X = double(A(:,:,1));
    % test if the wavelet transform can be computed without problems
    if (M==N) & (mod(M,8) == 0)
        Out = FuzzyShrink2(X,W);
        Out(:,:,2) = Out(:,:,1);
        Out(:,:,3) = Out(:,:,1);
    else
        iM = floor(log(M)/log(2));
        iN = floor(log(N)/log(2));

        Im1 = double(X(1:2^(iM),1:2^(iN),:));
        Im2 = double(X(1:2^(iM),N-2^(iN)+1:N,:));
        Im3 = double(X(M-2^(iM)+1:M,1:2^(iN),:));
        Im4 = double(X(M-2^(iM)+1:M,N-2^(iN)+1:N,:));
        
        clear Out1 Out2 Out3 Out4;
        Out1 = FuzzyShrink2(Im1,W);
        Out2 = FuzzyShrink2(Im2,W);
        Out3 = FuzzyShrink2(Im3,W);
        Out4 = FuzzyShrink2(Im4,W);
        [M1,N1]=size(Out1);
        [M2,N2]=size(Out2);
        [M3,N3]=size(Out3);
        [M4,N4]=size(Out4);

        Out(1:2^(iM),1:2^(iN))       = Out1; 
        Out(1:2^(iM),max(N-2^(iN)+1,2^(iN)-5):N)  = Out2(:,max(N-2^(iN)+1,2^(iN)-5) - (N-2^(iN)+1)+1:N2); 
        Out(max(M-2^(iM)+1,2^(iM)-5):M,1:2^(iN))  = Out3(max(M-2^(iM)+1,2^(iM)-5) - (M-2^(iM)+1)+1:M3,:); 
        Out(max(M-2^(iM)+1,2^(iM)-5):M,max(N-2^(iN)+1,2^(iN)-5):N) = Out4(max(M-2^(iM)+1,2^(iM)-5) - (M-2^(iM)+1)+1:M4,max(N-2^(iN)+1,2^(iN)-5) - (N-2^(iN)+1)+1:N4);  
        
        Out(:,:,2) = Out(:,:,1);
        Out(:,:,3) = Out(:,:,1);
    end
end