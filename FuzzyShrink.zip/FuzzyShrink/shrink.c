/***********************************************************************************************
 *
 * MATLAB:  SHRINK = shrink(D,W,sigma,rand);
 * 
 * 
 *  Goal: we calculate the shrinkage factor for a given input wavelet (sub)band. 
 *      The calculation is based on the fuzzy rule proposed in:
 *
 *  Stefan Schulte, Bruno Huysmans, Aleksandra Pizurica, Etienne E. Kerre and  Wilfried Philips: 
 *   A New Fuzzy-based Wavelet Shrinkage Image Denoising Technique
 *   submitted to the conference "Advanced Concepts for Intelligent Vision Systems" Sept 18-21, 2006,
 *   Antwerp, Belgium 
 * 
 *
 *  Input arguments:
 *       D: the noisy wavelet (sub)band
 *       W: neighbourhood size ((2*W+1)x(2*W+1))
 *   sigma: the standard deviation of the noise
 *  
 *  Output arguments:
 *    SHRINK: the shrinkage factor for each wavelet coef.
 *
 *  Stefan Schulte (stefan.schulte@Ugent.be)
 *  Last modified: 07/04/06
 *
 ************************************************************************************************/

#include "mex.h"
#include <math.h>

double LARGE (double x, double p1, double p2) {
   double res = 0.0;
   if ((x > p1) && (x < p2))   res = (x-p1)/(p2-p1);
   else if (x > p2)            res = 1.0;
   else                        res = 0.0;
   return res;
}

double MEDIUM (double x, double p1, double p2, double p3, double p4) {
   double res = 0.0;
   if ((x <= p1) && (x >= p4))    res = 0.0;
   else if ((x >= p2) && (x <= p3)) res = 1.0;
   else if ((x > p1) && (x < p2)) res = (x-p1)/(p2-p1);
   else  res = (p4-x)/(p4-p3);
   return res;
}

double absol(double a) {
   double b;
   if(a<0)   b=-a;
   else   b=a;
   return b;
}

double Mini(double a, double b) {
   double res;
   if (a <= b)   res=a;
   else   res = b;
   return res;
}

double Maxi(double a, double b) {
   double res;
   if (a >= b)   res=a;
   else  res = b;
   return res;
}

double Tnorm(double m1,double m2) {
   double res;
   res = m1*m2;
//    res = Mini(m1,m2);
//   res = Maxi(0,m1+m2-1);
   return res;
}

double Snorm(double m1,double m2) {
   double res;
   res = m1+m2-m1*m2;
//   res = Maxi(m1,m2);
//   res = Mini(1,m1+m2);
   return res;
}


/**************************************************************************************
*  The main function for the calculation of the shrinkage method
*
***************************************************************************************/
void callFuzzyShrink(double **D, double *S, int M, int N,  int W, double thr1, double thr2,
                double T1, double T2) { 
   int i,j,k,l;   
   double cen, mu_LA1, mu_LA2, mu_LA3, ave, ave2 ;
   int rand1a = 0;
   int rand1b = 0;
   int rand2a = 0;
   int rand2b = 0;
               
   for(i=0; i<M; i++){
      for(j=0; j<N; j++){
         /* step 1. Determine the local window*/      
         if(i < W) {
            rand1a = i;
            rand1b = W;
         }
         else {
              if (i>M-W-1){
               rand1a = W;
               rand1b = M-i-1;
            }
            else{
               rand1a = W;
               rand1b = W;
            }
         }

         
         if(j < W) {
            rand2a = j;
            rand2b = W;
         }
         else {
            if (j > N-W-1){
               rand2a = W;
               rand2b = N-j-1;
            }
            else{
               rand2a = W;
               rand2b = W;
            }
         }
         /* end step 1. */      
         
         /* step 2. Calculation of the shrinkage factor by using the fuzzy rule */      
         ave = 0.0;
         ave2 = 0.0;
         for(k=i-rand1a; k<=i+rand1b; k++){
	        for(l=j-rand2a; l<=j+rand2b; l++){
	           if ((k==i)&&(l==j)) continue;
	           else {
                  ave += absol(D[k][l]);
	           }
            }
         }
         for(k=i-Mini(rand1a,2); k<=i+Mini(rand1b,2); k++){
	        for(l=j-Mini(rand2a,2); l<=j+Mini(rand2b,2); l++){
	           if ((k==i)&&(l==j)) continue;
	           else {
                  ave2 += absol(D[k][l]);
	           }
            }
         }
         ave /= ((rand1a+rand1b+1)*(rand2a+rand2b+1)-1);
         ave2 /= ((Mini(rand1a,2)+Mini(rand1b,2)+1)*(Mini(rand2a,2)+Mini(rand2b,2)+1)-1);
         cen = absol(D[i][j]);
         
         mu_LA1 = LARGE(ave,T1,T2); 
         mu_LA2 = LARGE(cen,thr1,thr2);

  	     S[i+j*M] = (mu_LA1 * mu_LA2) + mu_LA1  - (mu_LA1 * mu_LA2 * mu_LA1);
 	  }
   }
}  /* End of callFuzzyShrink */



#define DETAIL  prhs[0]
#define WSIZE   prhs[1]
#define SIGMA   prhs[2]

#define Dc plhs[0]



/**
*  The interaction with Matlab (mex):
*        nlhs = amount of output arguments (= 1)
*        nrhs = amount of input arguments (= 3)
*     *plhs[] = link to the output 
*     *prhs[] = link to the input 
*
**/
void mexFunction( int nlhs, mxArray  *plhs[], int nrhs, const mxArray  *prhs[] ) {
    int row, col, i, M, N, W;
    double thr1,thr2,T1,T2, sigma;
    
    double **Dclear,**Detail;

    if (nlhs!=1)
        mexErrMsgTxt("It requires one output arguments only [Dclear].");
    if (nrhs!=3)
       mexErrMsgTxt("this method requires four input arguments [DETAIL WSIZE SIGMA RAND]");

    /* Get input values */  
    M = mxGetM(DETAIL);
    N = mxGetN(DETAIL);
    W = mxGetScalar(WSIZE);
    sigma = mxGetScalar(SIGMA);
    
    /**
    * Allocate memory for return matrices 
    **/
    Dc = mxCreateDoubleMatrix(M, N, mxREAL);  
    Dclear = mxGetPr(Dc);

    /**
    * Dynamic allocation of memory for the input array
    **/
    Detail = malloc(M*sizeof(int));
    for(i=0;i<M;i++)
      Detail[i] = malloc(N*sizeof(double));

     /**
     * Convert ARRAY_IN and INPUT_MASK to 2x2 C arrays (MATLAB stores a two-dimensional matrix 
     * in memory as a one-dimensional array) 
     ***/
     for (col=0; col < N; col++)
         for (row=0; row < M; row++) {
             Detail[row][col] = (mxGetPr(DETAIL))[row+col*M];
	      }

	 // the used parameters as shown in the paper     
 	 thr1 = 0;     
	 thr2 = 2.9*sigma - 2.625;     

	 T1 = sigma;     
	 T2 = 2*sigma;     
	
    /* Call callFuzzyShrink function */ 
    callFuzzyShrink(Detail,Dclear,M,N,W,thr1,thr2,T1,T2);

    for(i=0;i<M;i++)  free(Detail[i]);
    free(Detail); 
}
/* end mexFcn*/